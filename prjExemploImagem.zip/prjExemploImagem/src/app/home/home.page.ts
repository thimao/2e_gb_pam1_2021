import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  carros = [
    'carro1.jpg', //índice 0
    'carro2.jpg', //índice 1
    'carro3.jpg', //índice 2
    'carro4.jpeg' //índice 3
  ]
  carro = 'inicio.jpg'

  constructor() {}

  trocar(indice: number): void{
    this.carro = this.carros[indice]
  }
}

